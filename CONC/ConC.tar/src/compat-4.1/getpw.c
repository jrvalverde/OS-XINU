/****************************************
 *					*
 *    getpw.c				*
 *    Modified for mutual exclusion	*
 *					*
 ****************************************/

#include <kernel.h>
#undef NULL

/*
 * Copyright (c) 1980 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 */

#if defined(LIBC_SCCS) && !defined(lint)
static char sccsid[] = "@(#)getpw.c	5.2 (Berkeley) 3/9/86";
#endif LIBC_SCCS and not lint

#include	<stdio.h>

getpw(uid, buf)
int uid;
char buf[];
{
	static FILE *pwf;
	register n, c;
	register char *bp;

    swait(sem_sys_compat);
	if(pwf == 0)
		pwf = fopen("/etc/passwd", "r");
	if(pwf == (FILE *)NULL)
		{ssignal(sem_sys_compat); return(1);}
	rewind(pwf);

	for (;;) {
		bp = buf;
		while((c=getc(pwf)) != '\n') {
			if(c == EOF)
				{ssignal(sem_sys_compat); return(1);}
			*bp++ = c;
		}
		*bp++ = '\0';
		bp = buf;
		n = 3;
		while(--n)
		while((c = *bp++) != ':')
			if(c == '\n')
				{ssignal(sem_sys_compat); return(1);}
		while((c = *bp++) != ':') {
			if(c<'0' || c>'9')
				continue;
			n = n*10+c-'0';
		}
		if(n == uid)
			{ssignal(sem_sys_compat); return(0);}
	}
}
