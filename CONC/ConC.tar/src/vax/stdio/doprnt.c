/* doprnt.c  --  SEE doprnt.s */
