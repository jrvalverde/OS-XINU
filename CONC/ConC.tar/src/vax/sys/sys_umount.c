/* umount.c 4.2 83/05/10 */

#include "SYS.h"

SYSCALL(sys_umount)
	ret
