/* setrlimit.c */

/*
 *  Fall through to actual UNIX system call (no change for ConcurrenC).
 */
