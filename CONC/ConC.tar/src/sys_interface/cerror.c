/* cerror.c */

/*
 *  should not be called from user program, but not checked for.
 */
