/* ex1.c - print out 'hello world'  (without creating server because no
 *	   other task is created or started).
 */

main()
{
    printf("hello world.\n");
}
